<?php
    class Category{
        
    }
?>