<?php
    class Entry{
        
    }
?>