<?php

date_default_timezone_set("America/Toronto");

define("DB_HOST", "localhost");
define("DB_USER", "asanchez");
define("DB_PASSWORD", "sdnrrsdnrrscbhnscbhn");
define("DB_NAME", "asanchezblog");

// Add your blog name below
$config_blogname = "International Students Pathway Blog";

// Author
$config_author = "Alain Yosseph Rivera Sanchez";

?>
