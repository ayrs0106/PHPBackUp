<?php
use PDO;
use PDOException;
use SessionHandlerInterface;

namespace APP\Lib;

use App\Models\User;

class Session implements SessionHandlerInterface{
    private $user = false;

    public function __construct(){
        session_set_save_handler(SessionHandlerInterface,true);
        session_start();
        if(isset($_SESSION['user'])){
            $this->user = $_SESSION['user'];
        }
    }
    public function isLoggedIn(){
        return $this->user;
    }
    public function getUser(){
        return $this->user;
    }

    public function login(User $userObj): bool{
        $this->user = $userObj;
        $_SESSION['user']=$userObj;
        return true;
    }

    public function logout(): bool {
        $this->user=false;
        $_SESSION =[];
        session_destroy();
        return true;
    }

    public static function dbConnection(){}

    public function __destruct(){
        session_write_close();
    }

}