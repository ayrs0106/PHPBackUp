<?php
    define("DB_HOST", "localhost");
    define("DB_USER", "asanchez");
//    define("DB_PASSWORD", "9hc2j9hc2j");
    define("DB_PASSWORD", "sdnrrsdnrrscbhnscbhn");
    define("DB_NAME", "asanchezauction");

    define("CONFIG_ADMIN", "Alain Rivera");
    define("CONFIG_ADMINEMAIL", "ar109@myscc.ca");
    define("COMFIG_URL", "https://asanchez.scweb.ca/auction");
    define("CONFIG_AUCTIONNAME", "Web Auction");
    define("CONFIG+CURRENCY", "$");

    date_default_timezone_set("America/Toronto");

    define("LOG_LOCATION", __DIR__."/../../logs/app.log");

    define("FILE_UPLOADLOC", "imgs/");
